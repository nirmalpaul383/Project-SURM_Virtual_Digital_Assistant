The font file in this archive was created by Joanne Taylor in Knysna, South Africa, using Font Creator 5.6. 


By using or installing this font data, you implicitly agree to certain conditions:

It can be used for any commercial or personal work.
It must not be altered or modified without my consent.
It may not be sold.
I cannot be held liable for any damage arising out of the use of this font.

Please send a thumnail of any design work using this font to me,
qabbojo@gmail.com

Thank you for liking this font!
Enjoy
