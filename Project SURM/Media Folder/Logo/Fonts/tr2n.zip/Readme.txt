TR2N v1.0

ABOUT THE FONT:
A font based upon the poster text for TRON LEGACY.

The font is different from the pre-existing TRON font currently on the web.  Similar in minor aspects but different in most.  Style based upon text from different region posters.

Currently only the main letters and numbers are available, but updates are coming soon.

ABOUT THE AUTHOR:
Jeff Bell has produced fonts before, but this is the first one in over 10 years.  His original 3 fonts were under the name DJ-JOHNNYRKA and include "CASPER", "BEVERLY HILLS COP", "THE GODFATHER" and "FIDDUMS FAMILY".

For more information on Jeff Bell and his work can be found online:

www.randombell.com
www.damovieman.deviantart.com
http://www.imdb.com/name/nm3983081/
http://www.vimeo.com/user4004969/videos